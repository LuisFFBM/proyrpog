var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuw",
  1: "_",
  2: "cdegilopst",
  3: "_cdegilmoprst",
  4: "abcdefghilmnopst",
  5: "it",
  6: "bdes",
  7: "acdeilmnoprstuw",
  8: "bcdfhilmnrsw",
  9: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

