var searchData=
[
  ['n_5fids_1131',['n_ids',['../struct__Set.html#aff8fb061f3279f176735b4f9fcac2122',1,'_Set']]],
  ['n_5fres_5ferr_1132',['n_res_err',['../struct__Dialogue.html#a96e766a51c2d06bf9bc9739078be09ea',1,'_Dialogue']]],
  ['n_5fres_5fok_1133',['n_res_ok',['../struct__Dialogue.html#ae98c6e1ab89ec6fd3d35938f9b4e1930',1,'_Dialogue']]],
  ['n_5fslots_1134',['n_slots',['../struct__Slot.html#a0b9ab85038372e8070b28767edd10552',1,'_Slot']]],
  ['name_1135',['name',['../struct__Enemy.html#a21c1ab21970090bada8d9659589d4004',1,'_Enemy::name()'],['../struct__Link.html#a020ee863120055b29609157b9de3c84d',1,'_Link::name()'],['../struct__Object.html#a5fa5ea8f3caaeb4ab53d32cb6ee9b07b',1,'_Object::name()'],['../struct__Player.html#a5386de2d2371ad2c0c169cd2b57b5038',1,'_Player::name()'],['../struct__Space.html#aa1c9c994c2d16ecf3ef46138685fdfdc',1,'_Space::name()']]]
];
