var searchData=
[
  ['feedback_98',['feedback',['../struct__Graphic__engine.html#a4fc0ef353d000b20d57fb75d898c6d2d',1,'_Graphic_engine']]],
  ['feedback_5frows_99',['FEEDBACK_ROWS',['../graphic__engine_8c.html#a6e130f0e0fedb9b174f4212c83c58b97',1,'graphic_engine.c']]],
  ['frase_100',['frase',['../struct__Dialogue.html#aedaac323e05b8425d130bfb83d957090',1,'_Dialogue']]]
];
