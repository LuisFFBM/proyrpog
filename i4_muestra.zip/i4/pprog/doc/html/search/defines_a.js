var searchData=
[
  ['size_5flong_5fdesc_1224',['SIZE_LONG_DESC',['../types_8h.html#afede334c25c78c15ac9c3366df52738e',1,'types.h']]],
  ['size_5fshort_5fdesc_1225',['SIZE_SHORT_DESC',['../types_8h.html#add7345080a65cdd016594bc7aa9a7711',1,'types.h']]]
];
