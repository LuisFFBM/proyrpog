var searchData=
[
  ['feedback_1110',['feedback',['../struct__Graphic__engine.html#a4fc0ef353d000b20d57fb75d898c6d2d',1,'_Graphic_engine']]],
  ['frase_1111',['frase',['../struct__Dialogue.html#aedaac323e05b8425d130bfb83d957090',1,'_Dialogue']]]
];
