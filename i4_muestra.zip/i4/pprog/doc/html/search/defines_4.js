var searchData=
[
  ['help_5fcols_1206',['HELP_COLS',['../graphic__engine_8c.html#ac60dc30945336722712bf65e7cb5aa62',1,'graphic_engine.c']]],
  ['help_5frows_1207',['HELP_ROWS',['../graphic__engine_8c.html#ab2c964a57e93629d75fedcced614e2e5',1,'graphic_engine.c']]]
];
