var searchData=
[
  ['dialogue_5fcreate_691',['dialogue_create',['../dialogue_8h.html#acb150833c6f301d0311c2af653a56464',1,'dialogue_create():&#160;dialogue.c'],['../dialogue_8c.html#acb150833c6f301d0311c2af653a56464',1,'dialogue_create():&#160;dialogue.c']]],
  ['dialogue_5fdestroy_692',['dialogue_destroy',['../dialogue_8h.html#afdea7e120fcbe5a5953567ccadd34e07',1,'dialogue_destroy(Dialogue *d):&#160;dialogue.c'],['../dialogue_8c.html#afdea7e120fcbe5a5953567ccadd34e07',1,'dialogue_destroy(Dialogue *d):&#160;dialogue.c']]],
  ['dialogue_5fget_5ffrase_693',['dialogue_get_frase',['../dialogue_8h.html#ac4b9e08c37d4088b2a7b779d5c1f1f5d',1,'dialogue_get_frase(Dialogue *d, T_Command t_cmd, STATUS cmd_st, int res):&#160;dialogue.c'],['../dialogue_8c.html#ac4b9e08c37d4088b2a7b779d5c1f1f5d',1,'dialogue_get_frase(Dialogue *d, T_Command t_cmd, STATUS cmd_st, int res):&#160;dialogue.c']]],
  ['dialogue_5fset_5ffrase_694',['dialogue_set_frase',['../dialogue_8h.html#a78886a5dbd0551e2983f1b519207ffd9',1,'dialogue_set_frase(Dialogue *d, char *frase, T_Command t_cmd, STATUS cmd_st):&#160;dialogue.c'],['../dialogue_8c.html#a78886a5dbd0551e2983f1b519207ffd9',1,'dialogue_set_frase(Dialogue *d, char *frase, T_Command t_cmd, STATUS cmd_st):&#160;dialogue.c']]]
];
