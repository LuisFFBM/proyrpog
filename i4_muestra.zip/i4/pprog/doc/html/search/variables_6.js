var searchData=
[
  ['gdesc_1112',['gdesc',['../struct__Space.html#a88e909221b6ff33ce3f2974c88b92dc6',1,'_Space']]]
];
