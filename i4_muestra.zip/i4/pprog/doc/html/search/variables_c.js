var searchData=
[
  ['objects_1136',['objects',['../struct__Game.html#ad45bf5645a26e546d0060a2e61f9cf81',1,'_Game::objects()'],['../struct__Space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space::objects()']]],
  ['objs_1137',['objs',['../struct__Inventory.html#a9b5dc77b98754ec177f5062acbc18e8b',1,'_Inventory']]],
  ['open_1138',['open',['../struct__Link.html#a774c1858b4404738255f82b9a9d33955',1,'_Link::open()'],['../struct__Object.html#a0922dd9891e6aa617ce1d51ae27c0175',1,'_Object::open()']]],
  ['origin_1139',['origin',['../struct__Link.html#af039079d7500b5ab11ae21ef672cbf5f',1,'_Link']]]
];
